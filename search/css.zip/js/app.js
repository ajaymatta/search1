//twitterApp is dependent on the myApp.services module
var app = angular.module('twitterApp', ['ngSanitize','twitterApp.services','ngRoute']);

